// test.cpp
#include    <stdio.h>
#include    "foo.h"
 
int main()
{
    printf("Test: ");
    fooPrint();
    return 0;
}
