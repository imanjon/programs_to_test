// test.cpp
#include    <iostream>
#include    "foo.h"
 
using namespace std;
int main()
{
	cout << "Test: " << endl;
	Foo().Print();
    return 0;
}
