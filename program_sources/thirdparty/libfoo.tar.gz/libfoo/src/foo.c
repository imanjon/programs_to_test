#include    "foo.h"
#include    <stdio.h>
 
void fooPrint()
{
    printf("Hello, World!\n");
}
