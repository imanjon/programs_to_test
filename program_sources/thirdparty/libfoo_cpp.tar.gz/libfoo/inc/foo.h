// foo.h
#ifndef  FOO_INC
#define  FOO_INC
 
class Foo
{
   public:

   /**
    *   \brief  Función que imprime un mensaje
    */
   void Print();
}; // -----  end of class Foo  -----
 
#endif   // ----- #ifndef FOO_INC  -----
