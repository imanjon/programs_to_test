#include    "foo.h"
#include    <iostream>
 
using namespace std;
 
void Foo::Print()
{
   cout << "Hello, World!" << endl;
}
