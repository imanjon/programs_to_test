// foo.h
#ifndef  FOO_INC
#define  FOO_INC
 
/**
*   \brief  Función que imprime un mensaje
*/
void fooPrint();
 
#endif   // ----- #ifndef FOO_INC  -----
